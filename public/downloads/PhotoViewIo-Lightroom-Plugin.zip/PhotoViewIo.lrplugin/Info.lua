return {
  LrSdkVersion = 13.0,
  LrSdkMinimumVersion = 6.0,
  LrToolkitIdentifier = "com.photoviewpro.lightroom.export",
  LrPluginName = "PhotoView.io",

  LrExportServiceProvider = {
    title = "PhotoView.io",
    file = "PhotoViewIoExportServiceProvider.lua",
  },

  VERSION = {
    major = 0,
    minor = 3,
    revision = 1,
    build = 5,
  },
}
